# NEXUS Gaming Engine 1.4 — Premium

Proyecto Android nativo en Java, sin root, con interfaz negro/azul eléctrico. Objetivo inicial: Motorola Moto G24 con Android 14.

## Requisitos de compilación
- Android Gradle Plugin 8.7.3
- JDK 17
- Android SDK Platform 35
- `minSdk 26`, `targetSdk 35`

## Funciones de la versión 1.4
- Panel de estado con estimación global de RAM usada y memoria disponible.
- Historial visual local de las últimas 18 muestras de RAM mientras NEXUS está abierto.
- Temperatura de batería desde el broadcast estándar de batería.
- Estado térmico del sistema mediante `PowerManager` cuando Android/API y el firmware lo exponen.
- Alertas térmicas preventivas y recomendaciones.
- Nivel/estado de batería, tipo de conexión y almacenamiento disponible.
- Biblioteca de aplicaciones lanzables visibles para la app, búsqueda, favoritos y perfiles por aplicación.
- Perfiles generales Ahorro, Balanceado y Rendimiento. Son recomendaciones: Android conserva el control de CPU/GPU y del planificador.
- Cronómetro de sesión, tiempo acumulado e historial local de las últimas ocho sesiones.
- **Nuevo 1.4: compartir informe de diagnóstico** con modelo, versión Android, últimas métricas disponibles, perfil e historial de sesiones.
- **Nuevo 1.4: borrar historial y tiempo acumulado**, con confirmación.
- Modo sesión que mantiene la pantalla encendida mientras NEXUS está abierto.
- Actualización de métricas cada 3 segundos mientras la app está visible.

## Límites y precisión
NEXUS no hace overclock, no modifica voltajes/frecuencias, no libera por la fuerza RAM de otras apps, no bloquea procesos del sistema y no enfría físicamente el equipo. La temperatura visible es la de la batería, no una lectura directa del núcleo del procesador. El estado térmico depende de lo que exponga el firmware Motorola. La RAM es una estimación del sistema completo, no memoria atribuible a cada juego.

Android no garantiza acceso general a FPS por juego, carga detallada de GPU ni ping real medido desde cada juego. NEXUS no promete cambiar esos valores.

## Compilar APK
1. Abre el proyecto en Android Studio (PC) o un entorno Android compatible que soporte proyectos Gradle Android.
2. Usa JDK 17 y Android SDK Platform 35.
3. Sincroniza Gradle.
4. Ejecuta `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
5. El APK debug se genera en `app/build/outputs/apk/debug/app-debug.apk`.

Este paquete contiene código fuente, no un APK. No se ha compilado ni probado en un Motorola G24 físico. Se debe verificar la compilación y las lecturas reales en el dispositivo antes de distribuirlo.
