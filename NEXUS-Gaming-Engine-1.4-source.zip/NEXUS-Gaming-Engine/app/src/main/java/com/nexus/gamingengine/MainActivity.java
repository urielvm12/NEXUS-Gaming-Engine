package com.nexus.gamingengine;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.StatFs;
import android.os.SystemClock;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(7,10,17), PANEL=Color.rgb(15,23,36), BLUE=Color.rgb(38,181,255), WHITE=Color.rgb(237,245,255), MUTED=Color.rgb(137,157,181), GREEN=Color.rgb(68,220,164), AMBER=Color.rgb(255,190,75), RED=Color.rgb(255,91,111);
    private final Handler handler=new Handler(Looper.getMainLooper());
    private TextView ramValue,ramDetail,tempValue,tempDetail,batteryValue,batteryDetail,thermalText,networkValue,storageValue,profileText,sessionText,historyText,diagnosticText,gameCountText,sessionHistoryText;
    private int lastRamPercent=-1, lastThermalStatus=-1, lastBatteryPercent=-1;
    private float lastBatteryTemp=-1f;
    private String lastNetwork="NO DISPONIBLE", lastStorage="--";
    private LinearLayout gamesList,historyBars;
    private EditText gameSearch;
    private final Set<String> favoritePackages=new HashSet<>();
    private boolean session=false;
    private long sessionStartElapsed=0L;
    private long totalSessionSeconds=0L;
    private String profile="BALANCEADO";
    private final ArrayList<Integer> ramHistory=new ArrayList<>();
    private final Runnable updater=new Runnable(){@Override public void run(){refreshMetrics();handler.postDelayed(this,3000);}};
    private boolean criticalThermalDialogShown=false;
    private PowerManager.OnThermalStatusChangedListener thermalListener;

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);getWindow().getDecorView().setSystemUiVisibility(0);profile=getPreferences(0).getString("profile","BALANCEADO");favoritePackages.addAll(getPreferences(0).getStringSet("favorites",new HashSet<>()));totalSessionSeconds=getPreferences(0).getLong("total_session_seconds",0L);buildUI();refreshMetrics();}
    @Override protected void onResume(){super.onResume();handler.removeCallbacks(updater);handler.post(updater);if(Build.VERSION.SDK_INT>=29){PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);thermalListener=status->{if(status>=PowerManager.THERMAL_STATUS_SEVERE){runOnUiThread(()->showThermalWarning(status));}else if(status<PowerManager.THERMAL_STATUS_MODERATE){criticalThermalDialogShown=false;}};pm.addThermalStatusListener(thermalListener);}}
    @Override protected void onPause(){super.onPause();handler.removeCallbacks(updater);if(Build.VERSION.SDK_INT>=29&&thermalListener!=null){((PowerManager)getSystemService(POWER_SERVICE)).removeThermalStatusListener(thermalListener);thermalListener=null;}}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable bg(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return t;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout.LayoutParams p(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private void gap(LinearLayout l,int h){View v=new View(this);l.addView(v,p(1,h));}
    private void pad(View v,int n){v.setPadding(dp(n),dp(n),dp(n),dp(n));}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setTextColor(WHITE);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(bg(Color.rgb(12,104,164),BLUE,13));return b;}
    private void buildUI(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(BG);LinearLayout root=col();root.setPadding(dp(17),dp(14),dp(17),dp(30));sc.addView(root);setContentView(sc);
        LinearLayout brand=row();TextView mark=txt("N",25,BLUE,true);mark.setGravity(Gravity.CENTER);mark.setBackground(bg(PANEL,BLUE,13));brand.addView(mark,p(48,48));LinearLayout brandNames=col();LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(0,-2,1);blp.leftMargin=dp(11);brand.addView(brandNames,blp);brandNames.addView(txt("NEXUS",23,WHITE,true));brandNames.addView(txt("GAMING ENGINE  •  PREMIUM 1.4",9,MUTED,true));TextView live=txt("● LIVE",10,GREEN,true);brand.addView(live);root.addView(brand);gap(root,22);
        root.addView(txt("CENTRO DE CONTROL",10,BLUE,true));TextView heading=txt("Juega mejor.\nCuida tu equipo.",29,WHITE,true);root.addView(heading);gap(root,5);root.addView(txt("Herramientas inteligentes para tu Motorola G24.",12,MUTED,false));gap(root,16);
        LinearLayout hero=col();pad(hero,16);hero.setBackground(bg(PANEL,Color.rgb(27,83,119),18));LinearLayout hr=row();hr.addView(txt("ESTADO DEL DISPOSITIVO",10,MUTED,true));TextView refresh=txt("↻ ACTUALIZAR",10,BLUE,true);refresh.setGravity(Gravity.RIGHT);hr.addView(refresh,new LinearLayout.LayoutParams(0,-2,1));refresh.setOnClickListener(v->refreshMetrics());hero.addView(hr);gap(hero,15);
        LinearLayout metrics=row();LinearLayout a=col(),b=col(),c=col();ramValue=txt("--%",25,WHITE,true);ramDetail=txt("RAM EN USO",9,MUTED,true);a.addView(ramValue);a.addView(ramDetail);tempValue=txt("--°",25,WHITE,true);tempDetail=txt("TEMP. BATERÍA",9,MUTED,true);b.addView(tempValue);b.addView(tempDetail);batteryValue=txt("--%",25,WHITE,true);batteryDetail=txt("BATERÍA",9,MUTED,true);c.addView(batteryValue);c.addView(batteryDetail);metrics.addView(a,new LinearLayout.LayoutParams(0,-2,1));metrics.addView(b,new LinearLayout.LayoutParams(0,-2,1));metrics.addView(c,new LinearLayout.LayoutParams(0,-2,1));hero.addView(metrics);gap(hero,12);thermalText=txt("Estado térmico: recopilando…",11,MUTED,false);hero.addView(thermalText);root.addView(hero);gap(root,17);
        section(root,"PERFILES DE JUEGO","Selecciona un perfil de uso");LinearLayout profiles=row();profiles.addView(profileButton("AHORRO"),new LinearLayout.LayoutParams(0,dp(47),1));spaceH(profiles,6);profiles.addView(profileButton("BALANCEADO"),new LinearLayout.LayoutParams(0,dp(47),1));spaceH(profiles,6);profiles.addView(profileButton("RENDIMIENTO"),new LinearLayout.LayoutParams(0,dp(47),1));root.addView(profiles);profileText=txt("Perfil activo: "+profile+" · recomendaciones adaptadas",10,MUTED,false);gap(root,7);root.addView(profileText);gap(root,18);
        section(root,"MONITORES","Lecturas permitidas por Android");LinearLayout grid1=row();grid1.addView(infoCard("MEMORIA RAM","Uso y memoria disponible","▤"),new LinearLayout.LayoutParams(0,dp(94),1));spaceH(grid1,9);grid1.addView(infoCard("TEMPERATURA","Batería y estado térmico","◉"),new LinearLayout.LayoutParams(0,dp(94),1));root.addView(grid1);gap(root,9);LinearLayout grid2=row();grid2.addView(infoCard("BATERÍA","Nivel y estado de carga","ϟ"),new LinearLayout.LayoutParams(0,dp(94),1));spaceH(grid2,9);grid2.addView(infoCard("CONECTIVIDAD","Wi-Fi / datos móviles","⌁"),new LinearLayout.LayoutParams(0,dp(94),1));root.addView(grid2);gap(root,7);LinearLayout extra=row();extra.addView(txt("RED ACTIVA",9,MUTED,true),new LinearLayout.LayoutParams(0,-2,1));networkValue=txt("--",10,WHITE,true);extra.addView(networkValue);root.addView(extra);LinearLayout disk=row();disk.addView(txt("ALMACENAMIENTO DISPONIBLE",9,MUTED,true),new LinearLayout.LayoutParams(0,-2,1));storageValue=txt("--",10,WHITE,true);disk.addView(storageValue);root.addView(disk);gap(root,18);
        section(root,"ANÁLISIS EN VIVO","Tendencia reciente de uso de RAM");historyText=txt("Esperando mediciones…",10,MUTED,false);root.addView(historyText);historyBars=row();historyBars.setGravity(Gravity.BOTTOM);historyBars.setPadding(0,dp(8),0,0);root.addView(historyBars,p(-1,65));gap(root,18);
        section(root,"BIBLIOTECA DE JUEGOS","Toca para abrir · Mantén pulsado para favoritos y perfil individual");gameSearch=new EditText(this);gameSearch.setSingleLine(true);gameSearch.setTextColor(WHITE);gameSearch.setHintTextColor(MUTED);gameSearch.setHint("Buscar juego o aplicación…");gameSearch.setTextSize(13);gameSearch.setPadding(dp(13),dp(8),dp(13),dp(8));gameSearch.setBackground(bg(PANEL,Color.rgb(31,83,119),12));root.addView(gameSearch,p(-1,46));gameCountText=txt("",9,MUTED,false);gap(root,5);root.addView(gameCountText);gamesList=col();root.addView(gamesList);gameSearch.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){loadGames();}public void afterTextChanged(android.text.Editable e){}});loadGames();gap(root,17);
        section(root,"SESIÓN DE JUEGO","Cronómetro, estadísticas e historial local");Button sessionBtn=btn("⚡  ACTIVAR MODO SESIÓN");sessionBtn.setOnClickListener(v->toggleSession(sessionBtn));root.addView(sessionBtn,p(-1,50));sessionText=txt("Modo sesión desactivado",10,MUTED,false);gap(root,6);root.addView(sessionText);TextView sessionTotal=txt("Tiempo acumulado: "+formatDuration(totalSessionSeconds),9,MUTED,false);sessionTotal.setTag("session_total");gap(root,4);root.addView(sessionTotal);sessionHistoryText=txt(readSessionHistory(),10,MUTED,false);sessionHistoryText.setPadding(dp(12),dp(10),dp(12),dp(10));sessionHistoryText.setBackground(bg(PANEL,Color.rgb(31,47,67),12));gap(root,8);root.addView(sessionHistoryText);gap(root,17);
        section(root,"DIAGNÓSTICO","Recomendaciones según el estado actual");diagnosticText=txt("Preparando diagnóstico…",11,MUTED,false);diagnosticText.setPadding(dp(13),dp(12),dp(13),dp(12));diagnosticText.setBackground(bg(PANEL,Color.rgb(31,48,69),13));root.addView(diagnosticText);gap(root,14);
        Button tips=btn("GUÍA PREMIUM Y SEGURIDAD");tips.setOnClickListener(v->showGuide());root.addView(tips,p(-1,47));gap(root,14);TextView foot=txt("NEXUS NO REALIZA OVERCLOCK NI ALTERA LOS LÍMITES TÉRMICOS.\nAndroid controla la potencia y protege el dispositivo.",9,MUTED,false);foot.setGravity(Gravity.CENTER);root.addView(foot);
    }
    private void section(LinearLayout root,String title,String sub){root.addView(txt(title,10,BLUE,true));gap(root,3);root.addView(txt(sub,11,MUTED,false));gap(root,9);}
    private void spaceH(LinearLayout l,int w){View v=new View(this);l.addView(v,p(w,1));}
    private View infoCard(String title,String detail,String icon){LinearLayout c=col();pad(c,12);c.setBackground(bg(PANEL,Color.rgb(31,47,67),14));c.addView(txt(icon,18,BLUE,true));gap(c,3);c.addView(txt(title,10,WHITE,true));c.addView(txt(detail,9,MUTED,false));return c;}
    private Button profileButton(String name){Button b=btn(name);boolean active=profile.equals(name);b.setTextSize(9);b.setBackground(bg(active?Color.rgb(9,70,108):PANEL,active?BLUE:Color.rgb(40,57,78),12));b.setOnClickListener(v->{profile=name;getPreferences(0).edit().putString("profile",profile).apply();profileText.setText("Perfil activo: "+profile+" · "+profileAdvice());buildProfileButtonsRefresh();});return b;}
    private void buildProfileButtonsRefresh(){/* profile selection is advisory; Android owns CPU/GPU scheduling */ Toast.makeText(this,"Perfil "+profile+" activado. Se actualizaron tus recomendaciones.",Toast.LENGTH_SHORT).show();}
    private String profileAdvice(){if(profile.equals("AHORRO"))return "prioriza autonomía y brillo moderado";if(profile.equals("RENDIMIENTO"))return "prioriza estabilidad: cierra apps manualmente y baja gráficos si hay calor";return "equilibrio entre autonomía y fluidez";}
    private void refreshMetrics(){if(ramValue==null)return;try{if(session){long elapsed=(SystemClock.elapsedRealtime()-sessionStartElapsed)/1000L;sessionText.setText("Sesión activa · "+formatDuration(elapsed)+" · pantalla encendida");}TextView totalView=(TextView)findViewByTag(getWindow().getDecorView(),"session_total");if(totalView!=null)totalView.setText("Tiempo acumulado: "+formatDuration(totalSessionSeconds+(session?(SystemClock.elapsedRealtime()-sessionStartElapsed)/1000L:0L)));ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);int used=(int)(100L*(mi.totalMem-mi.availMem)/Math.max(1,mi.totalMem));lastRamPercent=used;ramValue.setText(used+"%");ramDetail.setText(formatBytes(mi.availMem)+" LIBRES");ramHistory.add(used);if(ramHistory.size()>18)ramHistory.remove(0);drawHistory();
        Intent bat=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));if(bat!=null){int lev=bat.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),scale=bat.getIntExtra(BatteryManager.EXTRA_SCALE,100);int pct=scale>0?lev*100/scale:0;lastBatteryPercent=pct;batteryValue.setText(pct+"%");int temp=bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,-1);if(temp>=0){float t=temp/10f;lastBatteryTemp=t;tempValue.setText(String.format(Locale.getDefault(),"%.1f°",t));tempDetail.setText("TEMP. BATERÍA");tempValue.setTextColor(t>=43?RED:t>=39?AMBER:WHITE);}int status=bat.getIntExtra(BatteryManager.EXTRA_STATUS,-1);batteryDetail.setText(status==BatteryManager.BATTERY_STATUS_CHARGING?"CARGANDO":status==BatteryManager.BATTERY_STATUS_FULL?"COMPLETA":"BATERÍA");}
        String thermal="No disponible";int ts=-1;if(Build.VERSION.SDK_INT>=29){PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);ts=pm.getCurrentThermalStatus();thermal=thermalName(ts);}lastThermalStatus=ts;thermalText.setText("Estado térmico del sistema: "+thermal);thermalText.setTextColor(ts>=4?RED:ts>=2?AMBER:GREEN);
        lastNetwork=getNetworkName();networkValue.setText(lastNetwork);StatFs fs=new StatFs(Environment.getDataDirectory().getAbsolutePath());lastStorage=formatBytes(fs.getAvailableBytes());storageValue.setText(lastStorage);String advice=diagnosis(used,ts,bat);diagnosticText.setText(advice);
        }catch(Exception e){if(diagnosticText!=null)diagnosticText.setText("Algunos datos no están disponibles en este firmware. Android mantiene sus protecciones activas.");}}
    private String diagnosis(int ram,int thermal,Intent battery){StringBuilder s=new StringBuilder();if(thermal>=4)s.append("ALERTA: el sistema informa temperatura elevada. Detén el juego, desconecta el cargador y deja enfriar el teléfono.\n\n");else if(thermal>=2)s.append("PRECAUCIÓN: temperatura moderada. Reduce gráficos y evita jugar mientras carga.\n\n");else s.append("Temperatura del sistema dentro de un estado no crítico o sin alerta reportada.\n\n");if(ram>=85)s.append("RAM muy ocupada: cierra manualmente aplicaciones que no necesites antes de abrir el juego.\n");else s.append("Memoria: no se detecta un uso extremo de RAM.\n");if(battery!=null){int l=battery.getIntExtra(BatteryManager.EXTRA_LEVEL,0);if(l<20)s.append("Batería baja: activa ahorro o carga antes de una sesión larga.\n");}s.append("Perfil ").append(profile).append(": ").append(profileAdvice()).append(".");return s.toString();}
    private void drawHistory(){if(historyBars==null)return;historyBars.removeAllViews();for(int value:ramHistory){View bar=new View(this);bar.setBackground(bg(value>85?RED:BLUE,0,4));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(Math.max(5,55*value/100)),1);lp.leftMargin=dp(2);lp.rightMargin=dp(2);historyBars.addView(bar,lp);}historyText.setText(ramHistory.size()+" muestras · actualización cada 3 segundos · RAM usada");}
    private String thermalName(int s){switch(s){case 0:return "NORMAL";case 1:return "LEVE";case 2:return "MODERADO";case 3:return "SEVERO";case 4:return "CRÍTICO";case 5:return "EMERGENCIA";case 6:return "APAGADO POR SISTEMA";default:return "DESCONOCIDO";}}
    private String formatBytes(long b){if(b<0)return "--";if(b<1073741824L)return String.format(Locale.getDefault(),"%.0f MB",b/1048576f);return String.format(Locale.getDefault(),"%.1f GB",b/1073741824f);}
    private String getNetworkName(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);Network n=cm.getActiveNetwork();if(n==null)return "SIN RED";NetworkCapabilities c=cm.getNetworkCapabilities(n);if(c==null)return "SIN RED";if(c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI))return "WI-FI";if(c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))return "DATOS MÓVILES";return "CONECTADO";}catch(Exception e){return "NO DISPONIBLE";}}
    private void loadGames(){if(gamesList==null)return;gamesList.removeAllViews();PackageManager pm=getPackageManager();Intent intent=new Intent(Intent.ACTION_MAIN,null);intent.addCategory(Intent.CATEGORY_LAUNCHER);List<android.content.pm.ResolveInfo> apps=pm.queryIntentActivities(intent,0);Collections.sort(apps,(a,b)->{boolean af=favoritePackages.contains(a.activityInfo.packageName),bf=favoritePackages.contains(b.activityInfo.packageName);if(af!=bf)return af?-1:1;return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());});String query=gameSearch==null?"":gameSearch.getText().toString().trim().toLowerCase(Locale.ROOT);int count=0,favs=0;for(android.content.pm.ResolveInfo info:apps){if(info.activityInfo.packageName.equals(getPackageName()))continue;ApplicationInfo ai=info.activityInfo.applicationInfo;if((ai.flags&ApplicationInfo.FLAG_SYSTEM)!=0)continue;String name=info.loadLabel(pm).toString(),pkg=info.activityInfo.packageName;boolean favorite=favoritePackages.contains(pkg);if(favorite)favs++;if(!query.isEmpty()&&!name.toLowerCase(Locale.ROOT).contains(query))continue;LinearLayout item=row();pad(item,10);item.setBackground(bg(PANEL,favorite?BLUE:Color.rgb(31,47,67),12));TextView initial=txt(name.substring(0,1).toUpperCase(Locale.ROOT),17,BLUE,true);initial.setGravity(Gravity.CENTER);initial.setBackground(bg(Color.rgb(8,39,59),0,9));item.addView(initial,p(38,38));LinearLayout labels=col();LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,-2,1);q.leftMargin=dp(10);item.addView(labels,q);labels.addView(txt(name,12,WHITE,true));String customProfile=getPreferences(0).getString("game_profile_"+pkg,"");labels.addView(txt((favorite?"★ FAVORITO":"Aplicación")+" · Perfil: "+(customProfile.isEmpty()?"GENERAL":customProfile),9,MUTED,false));item.addView(txt("ABRIR  ›",9,BLUE,true));item.setOnClickListener(v->{Intent launch=pm.getLaunchIntentForPackage(pkg);if(launch!=null)try{startActivity(launch);}catch(Exception ex){Toast.makeText(this,"No se pudo abrir la aplicación",Toast.LENGTH_SHORT).show();}});item.setOnLongClickListener(v->{showGameOptions(name,pkg);return true;});LinearLayout.LayoutParams ip=p(-1,-2);ip.bottomMargin=dp(6);gamesList.addView(item,ip);count++;}if(gameCountText!=null)gameCountText.setText(count+" resultados · "+favs+" favoritos guardados");if(count==0)gamesList.addView(txt("No hay coincidencias. Prueba con otro nombre.",11,MUTED,false));}
    private View findViewByTag(View root,String tag){if(tag.equals(root.getTag()))return root;if(root instanceof android.view.ViewGroup){android.view.ViewGroup group=(android.view.ViewGroup)root;for(int i=0;i<group.getChildCount();i++){View found=findViewByTag(group.getChildAt(i),tag);if(found!=null)return found;}}return null;}
    private String formatDuration(long seconds){long h=seconds/3600,m=(seconds%3600)/60,s=seconds%60;return String.format(Locale.getDefault(),"%02d:%02d:%02d",h,m,s);}
    private void toggleSession(Button b){session=!session;if(session){sessionStartElapsed=SystemClock.elapsedRealtime();getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);b.setText("✓  MODO SESIÓN ACTIVADO");sessionText.setText("Sesión iniciada · pantalla encendida mientras NEXUS permanezca abierto.");}else{long elapsed=Math.max(0,(SystemClock.elapsedRealtime()-sessionStartElapsed)/1000L);totalSessionSeconds+=elapsed;getPreferences(0).edit().putLong("total_session_seconds",totalSessionSeconds).apply();saveSessionHistory(elapsed);getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);b.setText("⚡  ACTIVAR MODO SESIÓN");sessionText.setText("Sesión finalizada · duración "+formatDuration(elapsed));if(sessionHistoryText!=null)sessionHistoryText.setText(readSessionHistory());}}
    @Override protected void onDestroy(){if(session){long elapsed=Math.max(0,(SystemClock.elapsedRealtime()-sessionStartElapsed)/1000L);totalSessionSeconds+=elapsed;getPreferences(0).edit().putLong("total_session_seconds",totalSessionSeconds).apply();saveSessionHistory(elapsed);session=false;}super.onDestroy();}
    private void showGameOptions(String name,String pkg){
        String[] options={favoritePackages.contains(pkg)?"Quitar de favoritos":"Añadir a favoritos","Perfil individual: AHORRO","Perfil individual: BALANCEADO","Perfil individual: RENDIMIENTO","Usar perfil general"};
        new AlertDialog.Builder(this).setTitle(name).setItems(options,(dialog,which)->{
            if(which==0){if(favoritePackages.contains(pkg))favoritePackages.remove(pkg);else favoritePackages.add(pkg);getPreferences(0).edit().putStringSet("favorites",new HashSet<>(favoritePackages)).apply();loadGames();}
            else if(which>=1&&which<=3){String selected=which==1?"AHORRO":which==2?"BALANCEADO":"RENDIMIENTO";getPreferences(0).edit().putString("game_profile_"+pkg,selected).apply();loadGames();Toast.makeText(this,"Perfil guardado para "+name,Toast.LENGTH_SHORT).show();}
            else{getPreferences(0).edit().remove("game_profile_"+pkg).apply();loadGames();Toast.makeText(this,"Usará el perfil general",Toast.LENGTH_SHORT).show();}
        }).show();
    }
    private void saveSessionHistory(long seconds){if(seconds<5)return;SharedPreferences prefs=getPreferences(0);String old=prefs.getString("session_history","");String entry=java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT,java.text.DateFormat.SHORT).format(new java.util.Date())+" · "+formatDuration(seconds);String updated=entry+(old.isEmpty()?"":"\n"+old);String[] lines=updated.split("\n");StringBuilder limited=new StringBuilder();for(int i=0;i<Math.min(8,lines.length);i++){if(i>0)limited.append("\n");limited.append(lines[i]);}prefs.edit().putString("session_history",limited.toString()).apply();}
    private String readSessionHistory(){String h=getPreferences(0).getString("session_history","");return "ÚLTIMAS SESIONES\n"+(h.isEmpty()?"Aún no hay sesiones registradas.":h);}
    private void showThermalWarning(int status){if(criticalThermalDialogShown||isFinishing())return;criticalThermalDialogShown=true;new AlertDialog.Builder(this).setTitle("NEXUS · ALERTA TÉRMICA").setMessage("Android detectó un estado térmico "+thermalName(status)+". Pausa el juego, desconecta el cargador si está conectado y deja que el teléfono se enfríe en un lugar ventilado. No lo metas al refrigerador ni uses hielo.").setPositiveButton("ENTENDIDO",(d,w)->{}).show();}

    private void shareDiagnosticReport(){
        StringBuilder report=new StringBuilder();
        report.append("NEXUS GAMING ENGINE 1.4\n");
        report.append("Dispositivo: ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append("\n");
        report.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n\n");
        report.append("DIAGNÓSTICO\n");
        report.append("RAM usada estimada: ").append(lastRamPercent<0?"No disponible":lastRamPercent+"%").append("\n");
        report.append("Batería: ").append(lastBatteryPercent<0?"No disponible":lastBatteryPercent+"%").append("\n");
        report.append("Temperatura de batería: ").append(lastBatteryTemp<0?"No disponible":String.format(Locale.getDefault(),"%.1f °C",lastBatteryTemp)).append("\n");
        report.append("Estado térmico Android: ").append(lastThermalStatus<0?"No disponible":thermalName(lastThermalStatus)).append("\n");
        report.append("Red: ").append(lastNetwork).append("\nAlmacenamiento disponible: ").append(lastStorage).append("\n");
        report.append("Perfil: ").append(profile).append("\nTiempo acumulado de sesiones: ").append(formatDuration(totalSessionSeconds)).append("\n\n");
        report.append(readSessionHistory()).append("\n\n");
        report.append("Nota: las lecturas dependen de lo que Android y el firmware expongan. RAM es una estimación global; la temperatura indicada es la de batería, no la del núcleo CPU. NEXUS no fuerza CPU/GPU ni enfría físicamente el teléfono.");
        Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_SUBJECT,"Informe NEXUS Gaming Engine 1.4");send.putExtra(Intent.EXTRA_TEXT,report.toString());startActivity(Intent.createChooser(send,"Compartir informe NEXUS"));
    }
    private void confirmClearHistory(){
        new AlertDialog.Builder(this).setTitle("Borrar historial de sesiones").setMessage("Se eliminarán las sesiones guardadas y el tiempo acumulado. Esta acción no se puede deshacer.").setNegativeButton("Cancelar",null).setPositiveButton("Borrar",(d,w)->{totalSessionSeconds=0L;getPreferences(0).edit().remove("session_history").putLong("total_session_seconds",0L).apply();if(sessionHistoryText!=null)sessionHistoryText.setText(readSessionHistory());TextView total=(TextView)findViewByTag(getWindow().getDecorView(),"session_total");if(total!=null)total.setText("Tiempo acumulado: "+formatDuration(0));Toast.makeText(this,"Historial borrado",Toast.LENGTH_SHORT).show();}).show();
    }
    private void showGuide(){String msg="NEXUS GAMING ENGINE · GUÍA PRO\n\nPERFILES\n• Ahorro: recomendaciones para sesiones largas y menor consumo.\n• Balanceado: uso general recomendado.\n• Rendimiento: prioriza estabilidad; reduce gráficos si hay tirones o calor.\n\nSEGURIDAD TÉRMICA\n• Evita jugar mientras cargas si el equipo se calienta.\n• Retira fundas gruesas durante sesiones calurosas.\n• Baja brillo y calidad gráfica si aparecen alertas.\n• Si Android indica temperatura crítica, pausa el juego y deja enfriar el teléfono.\n\nLIMITACIONES SIN ROOT\nAndroid no permite a una app normal hacer overclock, forzar frecuencias CPU/GPU, liberar por la fuerza la RAM de otras apps ni enfriar físicamente el equipo. Los perfiles NEXUS ajustan recomendaciones, no modifican el kernel.";new AlertDialog.Builder(this).setTitle("NEXUS · CENTRO DE AYUDA").setMessage(msg).setPositiveButton("ENTENDIDO",null).show();}
}
